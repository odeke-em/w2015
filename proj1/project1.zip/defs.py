#!/usr/bin/env python3

ACK  = 'A'
RECV = 'R'
WAYPOINT_PREFIX = 'N'
