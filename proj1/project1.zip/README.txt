Author: Emmanuel Odeke <odeke@ualberta.ca>

To run the program:

    `./reply.py < test.txt`
    OR
    `cat test.txt | ./reply.py`

this should start the protocol exchange.
